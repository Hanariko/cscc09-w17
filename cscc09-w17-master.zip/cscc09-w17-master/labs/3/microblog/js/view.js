var view = (function(){
    "use strict";
    
    var view = {};
    
    return view;
    
}());