var model = (function(){
    "use strict";
    
    var model = {};
    
    return model;
    
}());