---
title: Assignment 1 is out (deadline Sunday Jan 22, 11:59pm)
---

In assignment 1, you will build the fron-end of *The Web Gallery* app. You can find the handout in the *work* section of this website. Read the instructions carefully and I encourage you to discuss it on Piazza. 