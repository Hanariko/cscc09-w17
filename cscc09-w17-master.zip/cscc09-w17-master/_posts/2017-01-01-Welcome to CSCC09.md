---
title: Welcome to CSCC09
---

We will meet only for lectures on the first week of class. The labs will start the following week.
