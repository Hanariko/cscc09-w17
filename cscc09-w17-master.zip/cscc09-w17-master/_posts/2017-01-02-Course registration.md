---
title: Course registration (deadline Friday Jan 6, 11:59pm)
---

Each student will get a private Github repository to manage his/her course work. To setup this repository, I would ask you to:

1. create a github account (if you do not have one already) <https://github.com/>
1. fill the course registration form <https://goo.gl/forms/lKatnMZLx9ocom6j2>